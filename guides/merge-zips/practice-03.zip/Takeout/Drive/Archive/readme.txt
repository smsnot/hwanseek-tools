All nine files belong under one Takeout folder.
